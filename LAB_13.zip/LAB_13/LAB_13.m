A = imread('image.jpg');
subplot(2,2,1);
imshow(A);
title('FAISAL MOSQUE');
B = imrotate(A,45);
subplot(2,2,2);
imshow(B);
title('45 Degree Rotation');
C = rgb2gray(A);
subplot(2,2,3);
imshow(C);
title('Grey Filter');
imfinfo('image.jpg')
subplot(2,2,4);
imhist(C);
title('Histogram of Grey Filter Image');
imtool(A);
BW=edge(C,'canny');
DW=edge(C,'prewitt');
figure
imshowpair(BW,DW,'montage');

[r g b] = size(C);
z = zeros(r,g);
tempr = C;
tempr(:,:,2) = z;
tempr(:,:,3) = z;
figure
imshow(tempr);